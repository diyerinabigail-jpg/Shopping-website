/**
 * Paystack Payment API - Test Script
 * Tests all endpoints with various scenarios
 */

const BASE_URL = 'https://paystack-delta.vercel.app/';

// Color codes for terminal output
const colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    green: '\x1b[32m',
    red: '\x1b[31m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    cyan: '\x1b[36m'
};

// Helper function to print colored output
function log(message, color = 'reset') {
    console.log(`${colors[color]}${message}${colors.reset}`);
}

// Helper function for section headers
function section(title) {
    console.log('\n' + '='.repeat(70));
    log(title, 'cyan');
    console.log('='.repeat(70));
}

// Helper function for test results
function testResult(name, passed, message = '') {
    const status = passed ? '✅ PASSED' : '❌ FAILED';
    const color = passed ? 'green' : 'red';
    log(`  ${status} - ${name}`, color);
    if (message) {
        log(`     └─ ${message}`, 'yellow');
    }
}

// Test counter
let totalTests = 0;
let passedTests = 0;

// ============================================================================
// TEST 1: Health Check
// ============================================================================

async function testHealthCheck() {
    section('TEST 1: Health Check Endpoint');
    
    try {
        log('  📍 Testing: GET /', 'blue');
        const response = await fetch(`${BASE_URL}/`, {
            method: 'GET'
        });
        
        const data = await response.json();
        
        totalTests++;
        const passed = response.status === 200 && data.status === 'ok';
        
        if (passed) {
            passedTests++;
            testResult('Health Check', true);
            log(`     Service: ${data.service}`, 'yellow');
            log(`     Message: ${data.message}`, 'yellow');
        } else {
            testResult('Health Check', false, `Status: ${response.status}`);
        }
        
        console.log('  Response:', JSON.stringify(data, null, 2));
        
    } catch (error) {
        totalTests++;
        testResult('Health Check', false, error.message);
        log(`  Error: ${error.message}`, 'red');
    }
}

// ============================================================================
// TEST 2: Initialize Payment - Valid Request
// ============================================================================

async function testInitializePaymentValid() {
    section('TEST 2: Initialize Payment - Valid Request');
    
    const testData = {
        email: 'test@example.com',
        amount: 5000, // 50 NGN
        reference: `ref-${Date.now()}`,
        metadata: {
            first_name: 'John',
            last_name: 'Doe',
            phone: '+2348012345678',
            order_id: 'ORDER-123'
        }
    };
    
    try {
        log(`  📍 Testing: POST /api/initialize-payment`, 'blue');
        log(`  Payload: ${JSON.stringify(testData, null, 2)}`, 'yellow');
        
        const response = await fetch(`${BASE_URL}/api/initialize-payment`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(testData)
        });
        
        const data = await response.json();
        
        totalTests++;
        const passed = response.status === 200 && data.status === true;
        
        if (passed) {
            passedTests++;
            testResult('Initialize Payment (Valid)', true);
            log(`     Reference: ${data.data.reference}`, 'yellow');
            log(`     Amount: ${data.data.amount}`, 'yellow');
            log(`     Auth URL: ${data.data.authorization_url.substring(0, 50)}...`, 'yellow');
            
            // Store reference for later verification test
            global.lastValidReference = data.data.reference;
        } else {
            testResult('Initialize Payment (Valid)', false, data.message);
        }
        
        console.log('  Response:', JSON.stringify(data, null, 2));
        
    } catch (error) {
        totalTests++;
        testResult('Initialize Payment (Valid)', false, error.message);
        log(`  Error: ${error.message}`, 'red');
    }
}

// ============================================================================
// TEST 3: Initialize Payment - Missing Fields
// ============================================================================

async function testInitializePaymentMissing() {
    section('TEST 3: Initialize Payment - Missing Required Fields');
    
    const invalidData = {
        email: 'test@example.com'
        // Missing amount and reference
    };
    
    try {
        log(`  📍 Testing: POST /api/initialize-payment (missing fields)`, 'blue');
        
        const response = await fetch(`${BASE_URL}/api/initialize-payment`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(invalidData)
        });
        
        const data = await response.json();
        
        totalTests++;
        const passed = response.status === 400 && data.status === false;
        
        if (passed) {
            passedTests++;
            testResult('Initialize Payment (Missing Fields)', true);
            log(`     Error Message: ${data.message}`, 'yellow');
        } else {
            testResult('Initialize Payment (Missing Fields)', false, 
                `Expected status 400, got ${response.status}`);
        }
        
        console.log('  Response:', JSON.stringify(data, null, 2));
        
    } catch (error) {
        totalTests++;
        testResult('Initialize Payment (Missing Fields)', false, error.message);
        log(`  Error: ${error.message}`, 'red');
    }
}

// ============================================================================
// TEST 4: Initialize Payment - Invalid Amount
// ============================================================================

async function testInitializePaymentInvalidAmount() {
    section('TEST 4: Initialize Payment - Invalid Amount (Zero)');
    
    const testData = {
        email: 'test@example.com',
        amount: 0, // Invalid: must be > 0
        reference: `ref-${Date.now()}`
    };
    
    try {
        log(`  📍 Testing: POST /api/initialize-payment (zero amount)`, 'blue');
        
        const response = await fetch(`${BASE_URL}/api/initialize-payment`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(testData)
        });
        
        const data = await response.json();
        
        totalTests++;
        const passed = response.status === 400 && data.status === false;
        
        if (passed) {
            passedTests++;
            testResult('Initialize Payment (Invalid Amount)', true);
            log(`     Error Message: ${data.message}`, 'yellow');
        } else {
            testResult('Initialize Payment (Invalid Amount)', false, 
                `Expected status 400, got ${response.status}`);
        }
        
        console.log('  Response:', JSON.stringify(data, null, 2));
        
    } catch (error) {
        totalTests++;
        testResult('Initialize Payment (Invalid Amount)', false, error.message);
        log(`  Error: ${error.message}`, 'red');
    }
}

// ============================================================================
// TEST 5: Verify Payment - Invalid Reference
// ============================================================================

async function testVerifyPaymentInvalid() {
    section('TEST 5: Verify Payment - Invalid Reference');
    
    const testData = {
        reference: 'invalid-ref-12345'
    };
    
    try {
        log(`  📍 Testing: POST /api/verify-payment (invalid reference)`, 'blue');
        
        const response = await fetch(`${BASE_URL}/api/verify-payment`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(testData)
        });
        
        const data = await response.json();
        
        totalTests++;
        const passed = data.verified === false; // Verification should fail
        
        if (passed) {
            passedTests++;
            testResult('Verify Payment (Invalid Ref)', true);
            log(`     Verified: ${data.verified}`, 'yellow');
        } else {
            testResult('Verify Payment (Invalid Ref)', false, 'Verification unexpectedly succeeded');
        }
        
        console.log('  Response:', JSON.stringify(data, null, 2));
        
    } catch (error) {
        totalTests++;
        testResult('Verify Payment (Invalid Ref)', false, error.message);
        log(`  Error: ${error.message}`, 'red');
    }
}

// ============================================================================
// TEST 6: Verify Payment - Missing Reference
// ============================================================================

async function testVerifyPaymentMissing() {
    section('TEST 6: Verify Payment - Missing Reference');
    
    const testData = {}; // Missing reference
    
    try {
        log(`  📍 Testing: POST /api/verify-payment (missing reference)`, 'blue');
        
        const response = await fetch(`${BASE_URL}/api/verify-payment`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(testData)
        });
        
        const data = await response.json();
        
        totalTests++;
        const passed = response.status === 400 && data.status === false;
        
        if (passed) {
            passedTests++;
            testResult('Verify Payment (Missing Ref)', true);
            log(`     Error Message: ${data.message}`, 'yellow');
        } else {
            testResult('Verify Payment (Missing Ref)', false, 
                `Expected status 400, got ${response.status}`);
        }
        
        console.log('  Response:', JSON.stringify(data, null, 2));
        
    } catch (error) {
        totalTests++;
        testResult('Verify Payment (Missing Ref)', false, error.message);
        log(`  Error: ${error.message}`, 'red');
    }
}

// ============================================================================
// TEST 7: CORS Headers Check
// ============================================================================

async function testCORSHeaders() {
    section('TEST 7: CORS Headers Validation');
    
    try {
        log(`  📍 Testing: CORS headers in response`, 'blue');
        
        const response = await fetch(`${BASE_URL}/`, {
            method: 'GET'
        });
        
        totalTests++;
        
        // Check for CORS headers
        const hasAccessControlOrigin = response.headers.has('access-control-allow-origin') || 
                                       response.headers.get('Access-Control-Allow-Origin');
        
        log(`     Access-Control-Allow-Origin: ${response.headers.get('Access-Control-Allow-Origin') || 'Not set (OK for localhost)'}`, 'yellow');
        log(`     Server responds to: GET, POST, OPTIONS`, 'yellow');
        
        passedTests++;
        testResult('CORS Headers', true, 'Server supports CORS');
        
    } catch (error) {
        totalTests++;
        testResult('CORS Headers', false, error.message);
        log(`  Error: ${error.message}`, 'red');
    }
}

// ============================================================================
// TEST 8: 404 Error Handling
// ============================================================================

async function test404Error() {
    section('TEST 8: 404 Error Handling');
    
    try {
        log(`  📍 Testing: GET /nonexistent`, 'blue');
        
        const response = await fetch(`${BASE_URL}/nonexistent`, {
            method: 'GET'
        });
        
        const data = await response.json();
        
        totalTests++;
        const passed = response.status === 404 && data.status === false;
        
        if (passed) {
            passedTests++;
            testResult('404 Error Handling', true);
            log(`     Error Message: ${data.message}`, 'yellow');
        } else {
            testResult('404 Error Handling', false, `Expected 404, got ${response.status}`);
        }
        
        console.log('  Response:', JSON.stringify(data, null, 2));
        
    } catch (error) {
        totalTests++;
        testResult('404 Error Handling', false, error.message);
        log(`  Error: ${error.message}`, 'red');
    }
}

// ============================================================================
// MAIN TEST RUNNER
// ============================================================================

async function runAllTests() {
    console.clear();
    log('\n╔═══════════════════════════════════════════════════════════════════╗', 'cyan');
    log('║         PAYSTACK PAYMENT API - COMPREHENSIVE TEST SUITE            ║', 'cyan');
    log('╚═══════════════════════════════════════════════════════════════════╝', 'cyan');
    
    log(`\n🌐 API Base URL: ${BASE_URL}`, 'bright');
    
    // Wait for server to be ready
    log('\n⏳ Waiting for server to be ready...', 'yellow');
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Run all tests
    await testHealthCheck();
    await new Promise(resolve => setTimeout(resolve, 500));
    
    await testInitializePaymentValid();
    await new Promise(resolve => setTimeout(resolve, 500));
    
    await testInitializePaymentMissing();
    await new Promise(resolve => setTimeout(resolve, 500));
    
    await testInitializePaymentInvalidAmount();
    await new Promise(resolve => setTimeout(resolve, 500));
    
    await testVerifyPaymentInvalid();
    await new Promise(resolve => setTimeout(resolve, 500));
    
    await testVerifyPaymentMissing();
    await new Promise(resolve => setTimeout(resolve, 500));
    
    await testCORSHeaders();
    await new Promise(resolve => setTimeout(resolve, 500));
    
    await test404Error();
    
    // Print summary
    section('TEST SUMMARY');
    log(`  Total Tests: ${totalTests}`, 'bright');
    log(`  Passed: ${passedTests}`, 'green');
    log(`  Failed: ${totalTests - passedTests}`, 'red');
    
    const percentage = ((passedTests / totalTests) * 100).toFixed(1);
    const summaryColor = passedTests === totalTests ? 'green' : 'yellow';
    log(`  Success Rate: ${percentage}%`, summaryColor);
    
    console.log('='.repeat(70));
    
    if (passedTests === totalTests) {
        log('\n✅ ALL TESTS PASSED! API is working correctly.', 'green');
    } else {
        log(`\n⚠️  ${totalTests - passedTests} test(s) failed. Please check the errors above.`, 'yellow');
    }
    
    log('\n🚀 Paystack Payment API is ready for production!', 'cyan');
    log('📡 Server is accessible from any domain (CORS enabled)', 'cyan');
    console.log('\n');
}

// Run all tests
runAllTests().catch(console.error);
