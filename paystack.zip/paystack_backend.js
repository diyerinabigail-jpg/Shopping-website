/**
 * Paystack Payment Backend - Express.js Implementation
 * Complete backend for Paystack payment processing with callback handling
 * Fully CORS enabled and Vercel-ready
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const fs = require('fs/promises');
const os = require('os');
const path = require('path');

// ============================================================================
// CONFIGURATION
// ============================================================================

const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY;
const PAYSTACK_PUBLIC_KEY = process.env.PAYSTACK_PUBLIC_KEY;
const PAYSTACK_BASE_URL = 'https://api.paystack.co';
const CALLBACK_URL = process.env.CALLBACK_URL || 'https://paystack-delta.vercel.app/payment_callback';

function normalizeFrontendUrl(value) {
    const fallbackUrl = 'https://aacinema.com';
    if (!value || typeof value !== 'string') {
        return fallbackUrl;
    }

    const trimmed = value.trim();
    if (!trimmed) {
        return fallbackUrl;
    }

    try {
        const parsed = new URL(trimmed);
        const isVercelPathMistake = parsed.hostname.endsWith('vercel.app') && /aacinema\.com/i.test(parsed.pathname);
        if (isVercelPathMistake) {
            return 'https://aacinema.com';
        }

        const normalizedHost = parsed.hostname.replace(/^www\./i, '');
        return `${parsed.protocol}//${normalizedHost}`;
    } catch (error) {
        return trimmed.replace(/\/+$/, '').replace(/\/aacinema\.com\/?$/i, '') || fallbackUrl;
    }
}

const FRONTEND_URL = normalizeFrontendUrl(process.env.FRONTEND_URL || 'https://aacinema.com');
const MAILER_ENDPOINT = process.env.MAILER_ENDPOINT || 'https://o-my.vercel.app/send-email';
const ADMIN_EMAIL = process.env.ADMIN_EMAIL;
const EMAIL_STATUS_FILE = process.env.EMAIL_STATUS_FILE ||
    path.join(os.tmpdir(), 'paystack-booking-email-status.json');
const PORT = process.env.PORT || 3000;
let emailStatusQueue = Promise.resolve();

function requirePaystackSecret() {
    if (!PAYSTACK_SECRET_KEY) {
        throw new Error('PAYSTACK_SECRET_KEY is not configured');
    }
}

// Initialize Express app
const app = express();

// ============================================================================
// MIDDLEWARE
// ============================================================================

// CORS Configuration - Allow from anywhere
app.use(cors({
    origin: '*',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Body parsers
app.use(bodyParser.json({
    verify: (req, res, buffer) => {
        if (req.method === 'POST' && req.path === '/payment_callback') {
            req.rawBody = Buffer.from(buffer);
        }
    }
}));
app.use(bodyParser.urlencoded({ extended: true }));

// Logging middleware
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    next();
});

// ============================================================================
// PAYSTACK SERVICE
// ============================================================================

class PaystackPaymentService {
    /**
     * Initialize a Paystack payment transaction
     */
    static async initializePayment({
        email,
        amount,
        reference,
        metadata = {},
        callback_url = null
    }) {
        requirePaystackSecret();
        const url = `${PAYSTACK_BASE_URL}/transaction/initialize`;
        
        const headers = {
            'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`,
            'Content-Type': 'application/json'
        };
        
        const payload = {
            email,
            amount,
            reference,
            callback_url: callback_url || CALLBACK_URL,
            metadata
        };
        
        try {
            console.log(`[Paystack] Initializing payment: ref=${reference}, amount=${amount}`);
            console.log(`[Paystack] Initializing transaction for reference=${reference}`);
            
            const response = await axios.post(url, payload, { headers, timeout: 10000 });
            
            if (response.data.status) {
                console.log(`[Paystack] Payment initialized successfully: ref=${reference}`);
                
                return {
                    status: true,
                    message: 'Payment initialized successfully',
                    data: {
                        authorization_url: response.data.data.authorization_url,
                        access_code: response.data.data.access_code,
                        reference: response.data.data.reference || reference,
                        amount: response.data.data.amount || amount
                    }
                };
            } else {
                console.error(`[Paystack] Payment initialization failed:`, response.data.message);
                return {
                    status: false,
                    message: response.data.message || 'Failed to initialize payment'
                };
            }
        } catch (error) {
            console.error(`[Paystack] Request error:`, error.message);
            if (error.response?.data) {
                console.error(`[Paystack] API Error:`, error.response.data);
            }
            return {
                status: false,
                message: `Error initializing payment: ${error.message}`
            };
        }
    }
    
    /**
     * Verify a Paystack payment transaction
     */
    static async verifyPayment(reference) {
        requirePaystackSecret();
        const url = `${PAYSTACK_BASE_URL}/transaction/verify/${encodeURIComponent(reference)}`;
        
        const headers = {
            'Authorization': `Bearer ${PAYSTACK_SECRET_KEY}`
        };
        
        try {
            console.log(`[Paystack] Verifying payment: ref=${reference}`);
            
            const response = await axios.get(url, { headers, timeout: 10000 });
            
            if (response.data.status && response.data.data.status === 'success') {
                console.log(`[Paystack] Payment verified successfully: ref=${reference}`);
                
                return {
                    status: true,
                    verified: true,
                    message: 'Payment verified successfully',
                    data: {
                        reference: response.data.data.reference,
                        amount: response.data.data.amount,
                        currency: response.data.data.currency,
                        status: response.data.data.status,
                        paid_at: response.data.data.paid_at,
                        customer: response.data.data.customer,
                        metadata: response.data.data.metadata,
                        authorization: response.data.data.authorization
                    }
                };
            } else {
                console.warn(`[Paystack] Payment verification failed: ref=${reference}`);
                return {
                    status: false,
                    verified: false,
                    message: 'Payment verification failed'
                };
            }
        } catch (error) {
            console.error(`[Paystack] Verification error:`, error.message);
            return {
                status: false,
                verified: false,
                message: `Error verifying payment: ${error.message}`
            };
        }
    }
}

function withEmailStatusStore(update) {
    const operation = emailStatusQueue.then(async () => {
        let store;
        try {
            const content = await fs.readFile(EMAIL_STATUS_FILE, 'utf8');
            store = JSON.parse(content);
            if (!store || Array.isArray(store) || typeof store !== 'object') {
                throw new Error('Email status JSON must contain an object');
            }
        } catch (error) {
            if (error.code !== 'ENOENT') throw error;
            store = {};
        }

        const now = Date.now();
        for (const [key, record] of Object.entries(store)) {
            if (!record || record.expiresAt <= now) delete store[key];
        }

        const result = await update(store, now);
        const temporaryFile = EMAIL_STATUS_FILE + '.' + process.pid + '.' + crypto.randomUUID() + '.tmp';
        try {
            await fs.writeFile(temporaryFile, JSON.stringify(store), 'utf8');
            await fs.rename(temporaryFile, EMAIL_STATUS_FILE);
        } catch (error) {
            try {
                await fs.rm(temporaryFile, { force: true });
            } catch (cleanupError) {
                console.error('[Email] Could not remove temporary status file:', cleanupError.message);
            }
            throw error;
        }
        return result;
    });

    emailStatusQueue = operation.catch(() => {});
    return operation;
}

async function sendEmailOnce(reference, recipientType, email) {
    const referenceHash = crypto.createHash('sha256').update(reference).digest('hex');
    const key = 'ticket-email:' + referenceHash + ':' + recipientType;
    const lockValue = 'sending:' + crypto.randomUUID();
    const lockStatus = await withEmailStatusStore((store, now) => {
        const existingRecord = store[key];
        if (existingRecord?.status === 'sent') return 'sent';
        if (existingRecord?.status === 'sending' && existingRecord.expiresAt > now) return 'in-progress';

        store[key] = { status: 'sending', lockValue, expiresAt: now + 5 * 60 * 1000 };
        return 'claimed';
    });

    if (lockStatus === 'sent') {
        console.log('[Email] ' + recipientType + ' receipt already sent for reference=' + reference);
        return;
    }
    if (lockStatus === 'in-progress') {
        throw new Error('Email delivery for ' + recipientType + ' is already in progress');
    }

    let response;
    try {
        const mailerHost = new URL(MAILER_ENDPOINT).host;
        console.log('[Email] Sending ' + recipientType + ' notification for reference=' +
            reference + ' via=' + mailerHost);
        response = await axios.post(MAILER_ENDPOINT, {
            subject: email.subject,
            body: email.body,
            recipient_email: email.recipient
        }, { timeout: 10000 });

        if (response.data?.status !== 'success') {
            throw new Error('Mailer rejected ' + recipientType + ' email with HTTP ' +
                response.status + ' and status=' + String(response.data?.status || 'missing'));
        }

        await withEmailStatusStore(store => {
            if (store[key]?.lockValue !== lockValue) {
                throw new Error('Email delivery lock was lost for ' + recipientType);
            }
            store[key] = { status: 'sent', expiresAt: Date.now() + 365 * 24 * 60 * 60 * 1000 };
        });
        console.log('[Email] SUCCESS recipient=' + recipientType + ' reference=' + reference +
            ' mailer_http=' + response.status + ' mailer_status=' + response.data.status);
    } catch (error) {
        const httpStatus = error.response?.status || response?.status || 'unavailable';
        const mailerStatus = error.response?.data?.status || response?.data?.status || 'unavailable';
        const errorCode = error.code || 'none';
        console.error('[Email] FAILURE recipient=' + recipientType + ' reference=' + reference +
            ' mailer_http=' + httpStatus + ' mailer_status=' + mailerStatus +
            ' code=' + errorCode + ' error=' + error.message);
        try {
            await withEmailStatusStore(store => {
                if (store[key]?.lockValue === lockValue) delete store[key];
            });
        } catch (cleanupError) {
            console.error('[Email] Could not release ' + recipientType + ' delivery lock:', cleanupError.message);
        }
        throw error;
    }
}

function formatBookingDetails(metadata, payment) {
    const amountNaira = (payment.amount / 100).toLocaleString('en-NG');
    const ticketPrice = Number(metadata.ticketPrice);
    const quantity = Number(metadata.quantity);

    return [
        `Movie: ${metadata.package}`,
        `Movie ID: ${metadata.movie_id || 'N/A'}`,
        `Show date: ${metadata.date}`,
        `Showtime: ${metadata.showtime}`,
        `Tickets: ${quantity}`,
        `Ticket price: ₦${Number.isFinite(ticketPrice) ? ticketPrice.toLocaleString('en-NG') : 'N/A'}`,
        `Subtotal: ₦${Number(metadata.subtotal || 0).toLocaleString('en-NG')}`,
        `Booking fee: ₦${Number(metadata.booking_fee || 0).toLocaleString('en-NG')}`,
        `Amount paid: ₦${amountNaira}`,
        `Payment reference: ${payment.reference}`,
        `Booking submitted: ${metadata.timestamp || 'N/A'}`,
        `Paid at: ${payment.paid_at || 'N/A'}`
    ].join('\n');
}

async function sendTicketBookingEmails(payment) {
    const metadata = payment.metadata;
    const customerEmail = payment.customer?.email || metadata?.email;

    if (metadata?.booking_type !== 'ticket') {
        return false;
    }

    if (!ADMIN_EMAIL) {
        throw new Error('ADMIN_EMAIL is not configured; cannot send booking notifications');
    }

    const missingFields = [];
    if (!customerEmail) missingFields.push('customer email');
    if (!metadata.name) missingFields.push('customer name');
    if (!metadata.phone) missingFields.push('phone');
    if (!metadata.package) missingFields.push('movie');
    if (!metadata.date) missingFields.push('show date');
    if (!metadata.showtime) missingFields.push('showtime');
    if (!Number.isInteger(Number(metadata.quantity)) || Number(metadata.quantity) < 1) {
        missingFields.push('ticket quantity');
    }
    if (!Number.isFinite(Number(metadata.ticketPrice)) || Number(metadata.ticketPrice) <= 0) {
        missingFields.push('ticket price');
    }
    if (missingFields.length) {
        throw new Error('Verified transaction is missing ticket booking fields: ' + missingFields.join(', '));
    }

    const details = formatBookingDetails(metadata, payment);
    const customerEmailJob = {
        recipient: customerEmail,
        subject: `Your ticket booking receipt - ${payment.reference}`,
        body: [
            `Hello ${metadata.name},`,
            '',
            'Your payment was successful. Here is your ticket booking receipt:',
            '',
            details,
            '',
            'Please keep your payment reference for check-in.'
        ].join('\n')
    };
    const adminEmailJob = {
        recipient: ADMIN_EMAIL,
        subject: `Payment confirmed: ticket booking ${payment.reference}`,
        body: [
            'A ticket booking payment has been confirmed by Paystack.',
            '',
            `Customer: ${metadata.name}`,
            `Customer email: ${customerEmail}`,
            `Phone: ${metadata.phone || 'N/A'}`,
            details,
            `Notes: ${metadata.notes || 'None'}`
        ].join('\n')
    };

    await Promise.all([
        sendEmailOnce(payment.reference, 'customer', customerEmailJob),
        sendEmailOnce(payment.reference, 'admin', adminEmailJob)
    ]);

    console.log('[Email] All booking notifications processed successfully for reference=' +
        payment.reference);
    return true;
}

function validateSuccessfulTicketPayment(payment, reference, webhookData = null) {
    if (payment.reference !== reference ||
        payment.status !== 'success' ||
        payment.currency !== 'NGN') {
        throw new Error('Paystack transaction verification did not match a successful NGN payment');
    }

    if (webhookData &&
        (webhookData.reference !== payment.reference ||
            webhookData.amount !== payment.amount ||
            webhookData.currency !== payment.currency)) {
        throw new Error('Paystack webhook data did not match the verified transaction');
    }

    if (payment.metadata?.booking_type === 'ticket' &&
        (!Number.isFinite(Number(payment.metadata.total)) ||
            Math.round(Number(payment.metadata.total) * 100) !== payment.amount)) {
        throw new Error('Verified payment amount does not match the ticket booking total');
    }

    return payment;
}

// ============================================================================
// API ENDPOINTS
// ============================================================================

// Health check
app.get('/', (req, res) => {
    res.status(200).json({
        status: 'ok',
        message: 'Paystack Payment API is running',
        timestamp: new Date().toISOString(),
        service: 'Yumyum Paystack Payment Service'
    });
});

// Initialize payment
app.post('/api/initialize-payment', async (req, res) => {
    try {
        const { email, amount, reference, metadata, callback_url } = req.body;
        
        // Validate required fields
        if (!email || !amount || !reference) {
            return res.status(400).json({
                status: false,
                message: 'Missing required fields: email, amount, reference'
            });
        }
        
        // Validate amount
        if (!Number.isSafeInteger(Number(amount)) || Number(amount) <= 0) {
            return res.status(400).json({
                status: false,
                message: 'Amount must be a positive integer in kobo'
            });
        }

        if (metadata?.booking_type === 'ticket') {
            const requiredTicketFields = [
                'name', 'email', 'phone', 'date', 'showtime', 'package',
                'notes', 'timestamp'
            ];
            const missingFields = requiredTicketFields.filter(field =>
                typeof metadata[field] !== 'string' || !metadata[field].trim()
            );
            if (metadata.movie_id === undefined || metadata.movie_id === null ||
                (typeof metadata.movie_id !== 'string' && !Number.isSafeInteger(metadata.movie_id)) ||
                (typeof metadata.movie_id === 'string' && !metadata.movie_id.trim())) {
                missingFields.push('movie_id');
            }
            if (!Number.isInteger(Number(metadata.quantity)) || Number(metadata.quantity) < 1) {
                missingFields.push('quantity');
            }
            if (!Number.isFinite(Number(metadata.ticketPrice)) || Number(metadata.ticketPrice) <= 0) {
                missingFields.push('ticketPrice');
            }
            if (!Number.isFinite(Number(metadata.total)) ||
                Math.round(Number(metadata.total) * 100) !== Number(amount)) {
                missingFields.push('total matching payment amount');
            }
            if (missingFields.length) {
                return res.status(400).json({
                    status: false,
                    message: 'Ticket booking metadata is incomplete: ' + missingFields.join(', ')
                });
            }
        }
        
        // Initialize payment
        const result = await PaystackPaymentService.initializePayment({
            email,
            amount,
            reference,
            metadata: metadata || {},
            callback_url
        });
        
        const statusCode = result.status ? 200 : 400;
        res.status(statusCode).json(result);
        
    } catch (error) {
        console.error('[API] Error in initialize-payment:', error.message);
        res.status(500).json({
            status: false,
            message: `Server error: ${error.message}`
        });
    }
});

// Verify payment
app.post('/api/verify-payment', async (req, res) => {
    try {
        const { reference } = req.body;
        
        if (!reference) {
            return res.status(400).json({
                status: false,
                message: 'Missing required field: reference'
            });
        }
        
        const result = await PaystackPaymentService.verifyPayment(reference);
        
        const statusCode = result.verified ? 200 : 400;
        res.status(statusCode).json(result);
        
    } catch (error) {
        console.error('[API] Error in verify-payment:', error.message);
        res.status(500).json({
            status: false,
            message: `Server error: ${error.message}`
        });
    }
});

// Payment callback - Both GET and POST for Paystack webhook
app.get('/payment_callback', async (req, res) => {
    try {
        const { reference } = req.query;
        console.log(`[Callback GET] Received callback: ref=${reference}`);
        
        if (!reference) {
            console.warn('[Callback] Missing reference parameter');
            return res.status(400).send(`
                <!DOCTYPE html>
                <html>
                <head><title>Error</title></head>
                <body style="font-family: sans-serif; text-align: center; padding: 40px;">
                    <h1>❌ Error</h1>
                    <p>Missing payment reference. Please try again.</p>
                </body>
                </html>
            `);
        }
        
        console.log(`[Callback] Payment callback received: ref=${reference}`);
        
        // Verify payment with Paystack
        const verification = await PaystackPaymentService.verifyPayment(reference);
        
        if (verification.verified) {
            let emailNotificationsPending = false;
            try {
                const payment = validateSuccessfulTicketPayment(verification.data, reference);
                await sendTicketBookingEmails(payment);
            } catch (emailError) {
                emailNotificationsPending = true;
                console.error(`[Callback] Payment verified but email delivery is pending: ${emailError.message}`);
            }

            console.log(`[Callback] ✅ Payment verified successfully: ref=${reference}`);
            console.log(`[Callback] Payment amount: ${verification.data.amount}`);
            
            // Return success page with payment details
            return res.send(`
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Payment Successful</title>
                    <style>
                        * { margin: 0; padding: 0; box-sizing: border-box; }
                        body { 
                            font-family: 'Quicksand', -apple-system, BlinkMacSystemFont, sans-serif;
                            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                            min-height: 100vh;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            padding: 20px;
                        }
                        .container {
                            background: white;
                            border-radius: 15px;
                            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.3);
                            padding: 50px;
                            text-align: center;
                            max-width: 500px;
                            width: 100%;
                            animation: slideUp 0.5s ease;
                        }
                        @keyframes slideUp {
                            from { transform: translateY(30px); opacity: 0; }
                            to { transform: translateY(0); opacity: 1; }
                        }
                        .success-icon {
                            width: 100px;
                            height: 100px;
                            margin: 0 auto 30px;
                            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                            border-radius: 50%;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            font-size: 60px;
                            color: white;
                            animation: bounce 0.6s ease;
                        }
                        @keyframes bounce {
                            0%, 100% { transform: scale(1); }
                            50% { transform: scale(1.1); }
                        }
                        h1 { 
                            color: #333; 
                            margin-bottom: 15px; 
                            font-size: 32px;
                            font-weight: 700;
                        }
                        .amount {
                            font-size: 24px;
                            color: #667eea;
                            font-weight: 600;
                            margin: 20px 0;
                        }
                        .ref-id {
                            color: #999;
                            font-size: 12px;
                            word-break: break-all;
                            margin: 15px 0;
                            background: #f5f5f5;
                            padding: 10px;
                            border-radius: 5px;
                            font-family: monospace;
                        }
                        .message {
                            color: #666;
                            margin: 20px 0;
                            line-height: 1.6;
                        }
                        .buttons {
                            display: flex;
                            gap: 15px;
                            margin-top: 30px;
                        }
                        .btn {
                            flex: 1;
                            padding: 14px 24px;
                            border: none;
                            border-radius: 8px;
                            font-size: 15px;
                            font-weight: 600;
                            cursor: pointer;
                            text-decoration: none;
                            display: inline-block;
                            transition: all 0.3s ease;
                        }
                        .btn-primary {
                            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                            color: white;
                        }
                        .btn-primary:hover {
                            transform: translateY(-2px);
                            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="success-icon">✓</div>
                        <h1>Payment Successful! 🎉</h1>
                        
                        <div class="amount">₦${(verification.data.amount / 100).toLocaleString()}</div>
                        
                        <p class="message">
                            Your payment has been verified and processed successfully.
                        </p>
                        
                        <div class="ref-id">
                            <strong>Reference:</strong> ${reference}
                        </div>
                        
                        <p style="color: #999; font-size: 13px;">
                            ${emailNotificationsPending ? 'Payment confirmed. Your booking email is delayed; please keep your payment reference.' : 'Your booking email has been sent.'}
                        </p>
                        
                        <div class="buttons">
                            <a href="${FRONTEND_URL}" class="btn btn-primary">Back to Home</a>
                        </div>
                    </div>
                </body>
                </html>
            `);
        } else {
            console.error(`[Callback] ❌ Payment verification failed: ref=${reference}`);
            
            return res.send(`
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Payment Failed</title>
                    <style>
                        * { margin: 0; padding: 0; box-sizing: border-box; }
                        body { 
                            font-family: 'Quicksand', -apple-system, BlinkMacSystemFont, sans-serif;
                            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
                            min-height: 100vh;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            padding: 20px;
                        }
                        .container {
                            background: white;
                            border-radius: 15px;
                            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.3);
                            padding: 50px;
                            text-align: center;
                            max-width: 500px;
                            width: 100%;
                            animation: slideUp 0.5s ease;
                        }
                        @keyframes slideUp {
                            from { transform: translateY(30px); opacity: 0; }
                            to { transform: translateY(0); opacity: 1; }
                        }
                        .error-icon {
                            width: 100px;
                            height: 100px;
                            margin: 0 auto 30px;
                            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
                            border-radius: 50%;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            font-size: 60px;
                            color: white;
                        }
                        h1 { 
                            color: #333; 
                            margin-bottom: 15px; 
                            font-size: 28px;
                            font-weight: 700;
                        }
                        p { 
                            color: #666; 
                            margin-bottom: 15px; 
                            line-height: 1.6; 
                        }
                        .ref-id {
                            color: #999;
                            font-size: 12px;
                            word-break: break-all;
                            margin: 15px 0;
                            background: #f5f5f5;
                            padding: 10px;
                            border-radius: 5px;
                            font-family: monospace;
                        }
                        .buttons {
                            display: flex;
                            gap: 15px;
                            margin-top: 30px;
                            flex-wrap: wrap;
                        }
                        .btn {
                            flex: 1;
                            min-width: 140px;
                            padding: 14px 24px;
                            border: none;
                            border-radius: 8px;
                            font-size: 15px;
                            font-weight: 600;
                            cursor: pointer;
                            text-decoration: none;
                            display: inline-block;
                            transition: all 0.3s ease;
                        }
                        .btn-primary {
                            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
                            color: white;
                        }
                        .btn-primary:hover {
                            transform: translateY(-2px);
                            box-shadow: 0 8px 20px rgba(245, 87, 108, 0.4);
                        }
                        .btn-secondary {
                            background: #f5f5f5;
                            color: #333;
                            border: 2px solid #ddd;
                        }
                        .btn-secondary:hover {
                            background: #e8e8e8;
                            border-color: #999;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="error-icon">✕</div>
                        <h1>Payment Verification Failed</h1>
                        
                        <p>
                            We encountered an issue verifying your payment.
                        </p>
                        
                        <div class="ref-id">
                            <strong>Reference:</strong> ${reference}
                        </div>
                        
                        <p style="font-size: 13px; color: #999;">
                            If you were charged but didn't receive confirmation, 
                            please contact our support team with your reference ID.
                        </p>
                        
                        <div class="buttons">
                            <a href="${FRONTEND_URL}" class="btn btn-primary">Try Again</a>
                            <a href="mailto:support@yumyum.com" class="btn btn-secondary">Contact Support</a>
                        </div>
                    </div>
                </body>
                </html>
            `);
        }
    } catch (error) {
        console.error(`[Callback] ❌ Error processing callback: ${error.message}`);
        
        return res.send(`
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Payment Processing Error</title>
                <style>
                    * { margin: 0; padding: 0; box-sizing: border-box; }
                    body { 
                        font-family: 'Quicksand', -apple-system, BlinkMacSystemFont, sans-serif;
                        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
                        min-height: 100vh;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        padding: 20px;
                    }
                    .container {
                        background: white;
                        border-radius: 15px;
                        box-shadow: 0 15px 50px rgba(0, 0, 0, 0.3);
                        padding: 50px;
                        text-align: center;
                        max-width: 500px;
                        width: 100%;
                    }
                    h1 { color: #f44336; margin-bottom: 15px; font-size: 28px; }
                    p { color: #666; margin-bottom: 15px; line-height: 1.6; }
                    .error-detail {
                        background: #fff3cd;
                        border: 1px solid #ffc107;
                        color: #856404;
                        padding: 15px;
                        border-radius: 8px;
                        margin: 20px 0;
                        font-size: 12px;
                        word-break: break-word;
                    }
                    .btn {
                        display: inline-block;
                        padding: 14px 30px;
                        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
                        color: white;
                        text-decoration: none;
                        border-radius: 8px;
                        font-weight: 600;
                        margin-top: 20px;
                        transition: all 0.3s ease;
                    }
                    .btn:hover {
                        transform: translateY(-2px);
                        box-shadow: 0 8px 20px rgba(245, 87, 108, 0.4);
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>⚠️ Payment Processing Error</h1>
                    <p>An unexpected error occurred while processing your payment.</p>
                    <div class="error-detail">
                        Error: ${error.message}
                    </div>
                    <p style="font-size: 13px; color: #999;">
                        Please try again or contact support if the problem persists.
                    </p>
                    <a href="${FRONTEND_URL}" class="btn">Back to Home</a>
                </div>
            </body>
            </html>
        `);
    }
});

// Webhook endpoint - Paystack POST callback (backend-to-backend)
app.post('/payment_callback', async (req, res) => {
    try {
        const signature = req.get('x-paystack-signature');
        if (!PAYSTACK_SECRET_KEY || !Buffer.isBuffer(req.rawBody) ||
            typeof signature !== 'string' || !/^[a-f0-9]{128}$/i.test(signature)) {
            return res.status(400).json({ status: false, message: 'Invalid webhook signature' });
        }

        const expectedSignature = crypto
            .createHmac('sha512', PAYSTACK_SECRET_KEY)
            .update(req.rawBody)
            .digest();
        const receivedSignature = Buffer.from(signature, 'hex');

        if (receivedSignature.length !== expectedSignature.length ||
            !crypto.timingSafeEqual(receivedSignature, expectedSignature)) {
            return res.status(400).json({ status: false, message: 'Invalid webhook signature' });
        }
        
        const event = req.body.event;
        const webhookData = req.body.data || {};
        const { reference } = webhookData;
        
        if (event === 'charge.success') {
            if (typeof reference !== 'string' || !reference) {
                return res.status(400).json({ status: false, message: 'Missing payment reference' });
            }

            console.log(`[Webhook] Charge success received: ref=${reference}`);
            
            // Verify payment
            const verification = await PaystackPaymentService.verifyPayment(reference);
            
            if (verification.verified) {
                const payment = validateSuccessfulTicketPayment(
                    verification.data,
                    reference,
                    webhookData
                );
                await sendTicketBookingEmails(payment);
                
                return res.status(200).json({
                    status: true,
                    message: 'Payment verified and booking notifications processed',
                    reference: reference
                });
            } else {
                console.error(`[Webhook] Payment verification is not successful: ref=${reference}`);
                return res.status(503).json({
                    status: false,
                    message: 'Payment verification failed'
                });
            }
        } else {
            console.log(`[Webhook] Ignored event: ${event}`);
            return res.status(200).json({
                status: true,
                message: 'Webhook received',
                event: event
            });
        }
        
    } catch (error) {
        console.error(`[Webhook] ❌ Error processing webhook: ${error.message}`);
        return res.status(500).json({
            status: false,
            message: `Webhook error: ${error.message}`
        });
    }
});

// API endpoint to check payment status (for frontend to call)
app.post('/api/check-payment', async (req, res) => {
    try {
        const { reference } = req.body;
        
        if (!reference) {
            return res.status(400).json({
                status: false,
                message: 'Missing reference parameter'
            });
        }
        
        console.log(`[API] Checking payment status: ref=${reference}`);
        
        const verification = await PaystackPaymentService.verifyPayment(reference);
        
        res.status(200).json(verification);
        
    } catch (error) {
        console.error('[API] Error checking payment:', error.message);
        res.status(500).json({
            status: false,
            message: `Error checking payment: ${error.message}`
        });
    }
});

// ============================================================================
// ERROR HANDLING
// ============================================================================

app.use((err, req, res, next) => {
    console.error('[Error]', err);
    res.status(500).json({
        status: false,
        message: 'Internal server error',
        error: err.message
    });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        status: false,
        message: 'Endpoint not found'
    });
});

// ============================================================================
// STARTUP
// ============================================================================

if (process.env.VERCEL === '1') {
    // Serverless export for Vercel
    module.exports = app;
} else {
    // Local development
    app.listen(PORT, () => {
        console.log('\n' + '='.repeat(60));
        console.log('🚀 Paystack Payment API Server');
        console.log('='.repeat(60));
        console.log(`📡 Server listening at http://localhost:${PORT}`);
        console.log(`🌐 Frontend URL: ${FRONTEND_URL}`);
        console.log(`📞 Callback URL: ${CALLBACK_URL}`);
        console.log('='.repeat(60) + '\n');
    });
}
